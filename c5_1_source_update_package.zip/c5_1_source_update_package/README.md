# Capstone C5.1 Source Update Package

## Purpose

This package is a C5.1-ready source document set prepared from the uploaded C5 source archive and the Week 10-12 meeting context.

C5.1 is not a full dashboard/app implementation phase.  
C5.1 is the core simulation and heuristic comparison foundation.

## C5.1 Definition

C5.1 is the version that compares H0 baseline and H1-H4 heuristic policies under the same mine simulation environment, same demand scenario, and same seed control.

The output of C5.1 must be standardized logs, KPI summaries, and a simulation visualization MVP.

## Current In Scope

- C5.1 scope and implementation documents
- C5.1 configs
- cost model
- maintenance action model
- policy interface
- H0-H4 policy specification
- policy sweep specification
- KPI/report specification
- simulation visualization MVP specification

## Deferred Until Separate Instruction

- Operator dashboard implementation
- PM Android app implementation
- Dashboard-app integration
- PPO/RL training
- Drop Zone scenario implementation

## Recommended Usage

1. Create a new GitHub repository or new local project folder.
2. Copy this package into the new folder.
3. Keep `AGENTS.md` and `CURRENT_TASK.md` at the repository root.
4. Ask Codex to follow `prompts/CODEX_NEW_FOLDER_SETUP_PROMPT.md`.
5. Do not allow Codex to implement dashboard/app unless separately instructed.
