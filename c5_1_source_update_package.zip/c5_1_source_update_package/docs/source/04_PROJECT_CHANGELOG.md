# 04_PROJECT_CHANGELOG.md

## Purpose

This changelog tracks the official direction changes for C5.1.

---

## 2026-05-18 / Week 10 Feedback

- Professor feedback reframed the project as a mine truck transport simulation and PM scheduling problem.
- Priority changed from RL-first to simulation visualization + heuristic baseline.
- RL was moved to a later comparison target.
- Project explanation must use the team's own operational language, not GPT-generated abstraction.

---

## 2026-05-19 / Week 11 Mid-Presentation

- Project direction was positioned as industrial engineering scheduling + preventive maintenance.
- Working simulation, heuristic comparison, and interpretable outputs were confirmed as important.
- The presentation should reveal problem definition and direction, not detailed formulas or code.

---

## 2026-05-25 / Week 12 Meeting

- C5.1 scope fixed as a heuristic comparison foundation.
- H0 baseline and H1-H4 policies will be compared under the same environment.
- Drop Zone is not treated as a heuristic. It is deferred as a separate environment scenario.
- Operator dashboard, PM app, and integration are deferred until separate instruction.
- C5.1 must export logs and KPI summaries for later visualization/dashboard/app use.

---

## Current Official Version

| Item | Value |
|---|---|
| Version | C5.1 |
| Main scope | Simulation + heuristic comparison |
| Required policies | H0, H1, H2, H3, H4 |
| Required outputs | logs, KPI summary, visualization MVP |
| Deferred | RL, dashboard, PM app, integration, Drop Zone |
